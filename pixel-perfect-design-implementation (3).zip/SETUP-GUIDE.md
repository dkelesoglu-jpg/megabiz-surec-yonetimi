# Megabiz Kurulum Rehberi

Bu rehber, Megabiz İş Talimatları ve Süreç Yönetim Sistemini sıfırdan kurmak için adım adım talimatlar içerir.

## 📋 Gereksinimler

- Node.js 18+ 
- npm veya yarn
- Supabase hesabı (ücretsiz)
- Modern web tarayıcı

## 🎯 Adım 1: Proje Kurulumu

### 1.1 Proje Dosyalarını İndirin

```bash
# Projeyi klonlayın veya ZIP olarak indirin
git clone <repository-url>
cd megabiz
```

### 1.2 Bağımlılıkları Yükleyin

```bash
npm install
```

## 🗄️ Adım 2: Supabase Kurulumu

### 2.1 Supabase Hesabı Oluşturma

1. [https://supabase.com](https://supabase.com) adresine gidin
2. "Start your project" butonuna tıklayın
3. GitHub/Google ile giriş yapın

### 2.2 Yeni Proje Oluşturma

1. "New Project" butonuna tıklayın
2. Proje detaylarını doldurun:
   - **Name**: Megabiz
   - **Database Password**: Güçlü bir şifre oluşturun (kaydedin!)
   - **Region**: Size en yakın bölgeyi seçin (Europe - Frankfurt önerilir)
   - **Pricing Plan**: Free tier seçilebilir
3. "Create new project" butonuna tıklayın
4. Proje hazır olana kadar bekleyin (1-2 dakika)

### 2.3 API Bilgilerini Alma

1. Sol menüden **Settings** > **API** bölümüne gidin
2. Aşağıdaki bilgileri kopyalayın:
   - **Project URL** (örn: `https://abcdefgh.supabase.co`)
   - **anon public** key (uzun bir string)

### 2.4 Environment Dosyasını Oluşturma

1. Proje kök dizininde `.env.example` dosyasını `.env` olarak kopyalayın:

```bash
cp .env.example .env
```

2. `.env` dosyasını açın ve bilgileri doldurun:

```env
VITE_SUPABASE_URL=https://abcdefgh.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGc...uzun-key-buraya
```

## 🏗️ Adım 3: Veritabanı Şemasını Oluşturma

### 3.1 SQL Editor'ü Açma

1. Supabase Dashboard'da sol menüden **SQL Editor** seçin
2. "New Query" butonuna tıklayın

### 3.2 Schema SQL'ini Çalıştırma

1. `database-schema.sql` dosyasını bir metin editöründe açın
2. Tüm içeriği kopyalayın
3. Supabase SQL Editor'e yapıştırın
4. "Run" (veya F5) butonuna tıklayın
5. Başarılı mesajını bekleyin

**Beklenen Sonuç:**
```
Success. No rows returned
```

### 3.3 Örnek Verileri Yükleme

1. SQL Editor'de yeni bir query açın
2. `database-seed.sql` dosyasının içeriğini kopyalayın
3. SQL Editor'e yapıştırın
4. "Run" butonuna tıklayın

**Beklenen Sonuç:**
```
Success. X rows affected
```

### 3.4 Tabloları Kontrol Etme

1. Sol menüden **Table Editor** seçin
2. Aşağıdaki tabloların oluşturulduğunu doğrulayın:
   - departments (6 kayıt)
   - positions (16 kayıt)
   - employees (henüz boş)
   - job_descriptions (2 kayıt)
   - work_instructions (5 kayıt)
   - documents (henüz boş)
   - kpis (henüz boş)
   - performance_reviews (henüz boş)

## 📁 Adım 4: Storage Bucket Oluşturma

### 4.1 Storage Bölümüne Gitme

1. Sol menüden **Storage** seçin
2. "Create a new bucket" butonuna tıklayın

### 4.2 Bucket Ayarları

- **Name**: `documents`
- **Public bucket**: ✅ İşaretleyin (dosyaların görüntülenebilmesi için)
- "Create bucket" butonuna tıklayın

### 4.3 Bucket Politikalarını Ayarlama

1. Oluşturduğunuz `documents` bucket'ına tıklayın
2. "Policies" sekmesine gidin
3. "New Policy" > "Custom" seçin
4. Aşağıdaki politikayı ekleyin:

**Policy Name**: Allow authenticated users to upload

**Allowed operation**: INSERT

**Policy definition**:
```sql
(auth.role() = 'authenticated')
```

5. Benzer şekilde SELECT için de politika ekleyin:

**Policy Name**: Allow all to view

**Allowed operation**: SELECT

**Policy definition**:
```sql
true
```

## 👤 Adım 5: İlk Kullanıcıyı Oluşturma

### 5.1 Kullanıcı Kaydı

1. Sol menüden **Authentication** > **Users** seçin
2. "Add user" > "Create new user" seçin
3. Kullanıcı bilgilerini doldurun:
   - **Email**: admin@megabiz.com
   - **Password**: Güçlü bir şifre
   - **Auto Confirm User**: ✅ İşaretleyin
4. "Create user" butonuna tıklayın
5. Oluşturulan kullanıcının **UUID**'sini kopyalayın

### 5.2 Employee Kaydı Ekleme

1. **Table Editor** > **employees** tablosuna gidin
2. "Insert" > "Insert row" seçin
3. Aşağıdaki bilgileri doldurun:

```
user_id: [Kopyaladığınız UUID]
position_id: p0000000-0000-0000-0000-000000000001 (Genel Müdür)
first_name: Admin
last_name: Yönetici
email: admin@megabiz.com
phone: (isteğe bağlı)
hire_date: 2024-01-01 (veya bugünün tarihi)
role: admin
is_active: true
```

4. "Save" butonuna tıklayın

## 🚀 Adım 6: Uygulamayı Çalıştırma

### 6.1 Development Server'ı Başlatma

```bash
npm run dev
```

Konsol çıktısı:
```
VITE v7.x.x ready in xxx ms

➜  Local:   http://localhost:5173/
➜  Network: use --host to expose
```

### 6.2 Tarayıcıda Açma

1. Tarayıcınızda `http://localhost:5173` adresine gidin
2. Login ekranı görünmelidir

### 6.3 Giriş Yapma

- **Email**: admin@megabiz.com
- **Password**: Oluşturduğunuz şifre

## ✅ Adım 7: Kurulum Doğrulama

Başarılı kurulum kontrolü:

### Dashboard
- [ ] Toplam Pozisyon: 16
- [ ] Departman Sayısı: 6
- [ ] Aktif Çalışan: 1
- [ ] İş Talimatları: 5
- [ ] Departman dağılım grafiği görüntüleniyor

### Organizasyon Yapısı
- [ ] Organizasyon şeması görüntüleniyor
- [ ] Genel Müdür en üstte
- [ ] 5 ana departman müdürü altında
- [ ] Pozisyonlara tıklanabiliyor
- [ ] Zoom kontrolleri çalışıyor

### İş Talimatları
- [ ] 5 örnek talimat listeleniyor
- [ ] Talimatlar filtrelenebiliyor

## 🔧 Sorun Giderme

### Problem: "Invalid API key" hatası

**Çözüm:**
1. `.env` dosyasındaki `VITE_SUPABASE_ANON_KEY` değerini kontrol edin
2. Supabase Dashboard > Settings > API'den doğru key'i kopyalayın
3. Development server'ı yeniden başlatın (`npm run dev`)

### Problem: "Failed to fetch" hatası

**Çözüm:**
1. `.env` dosyasındaki `VITE_SUPABASE_URL` doğru mu kontrol edin
2. İnternet bağlantınızı kontrol edin
3. Supabase proje durumunu kontrol edin (Dashboard'da)

### Problem: Tablolar görünmüyor

**Çözüm:**
1. SQL Editor'de `database-schema.sql` tekrar çalıştırın
2. Table Editor'de tabloların oluştuğunu kontrol edin
3. Browser console'da hata var mı kontrol edin (F12)

### Problem: Login çalışmıyor

**Çözüm:**
1. Supabase Dashboard > Authentication > Users'da kullanıcı var mı kontrol edin
2. Email confirmed mı kontrol edin
3. employees tablosunda kayıt var mı kontrol edin
4. user_id'ler eşleşiyor mu kontrol edin

### Problem: RLS hatası (Row Level Security)

**Çözüm:**
1. SQL Editor'de `database-schema.sql` içindeki policy'leri tekrar çalıştırın
2. Table Editor > [tablo] > Policies'de politikaların aktif olduğunu kontrol edin

## 📊 Ek Kullanıcı Ekleme

Daha fazla kullanıcı eklemek için:

1. **Authentication** > **Users**'da yeni kullanıcı oluşturun
2. **employees** tablosuna kayıt ekleyin
3. İlgili pozisyonu atayın
4. Rolü belirleyin (admin/general_manager/manager/employee)

## 🎨 Örnek Veri Ekleme

### Yeni Departman

```sql
INSERT INTO departments (name, color) VALUES
('Ar-Ge', 'indigo');
```

### Yeni Pozisyon

```sql
INSERT INTO positions (title, department_id, manager_position_id, level) VALUES
('Yazılım Geliştirici', '[department-uuid]', '[manager-position-uuid]', 2);
```

### Yeni İş Talimatı

```sql
INSERT INTO work_instructions (code, title, department_id, version, status) VALUES
('IT-006', 'Yazılım Geliştirme Süreci', '[department-uuid]', 'v1.0', 'draft');
```

## 📞 Destek

Sorun yaşarsanız:

1. README.md dosyasını kontrol edin
2. GitHub Issues bölümüne bakın
3. Supabase dokümantasyonuna başvurun: https://supabase.com/docs

## 🎉 Tebrikler!

Megabiz sistemi başarıyla kuruldu! Artık kullanmaya başlayabilirsiniz.

### Sonraki Adımlar:

1. Kalan pozisyonlara çalışanları atayın
2. Görev tanımları yükleyin
3. İş talimatlarını tamamlayın
4. Dokümanları sisteme aktarın
5. KPI'ları tanımlayın

---

**Önemli Güvenlik Notları:**

- `.env` dosyasını asla Git'e commit etmeyin
- Production'da güçlü şifreler kullanın
- Supabase RLS politikalarını proje ihtiyaçlarına göre özelleştirin
- Düzenli yedekleme yapın
